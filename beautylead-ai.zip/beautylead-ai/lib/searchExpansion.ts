/**
 * Expands a user's search term into related terms so the provider layer
 * casts a wider net (e.g. "Hair Stylist" also searches "Silk Press",
 * "Natural Hair", "Black Hair Salon", ...).
 *
 * In production this calls OpenAI (see lib/ai/expandSearchTerm.ts) with a
 * prompt like: "List 10 closely related search terms a beauty client might
 * use for '{term}'". This static map covers the categories named in the
 * product spec and acts as an instant, zero-latency fallback when the AI
 * call is disabled or rate-limited — the AI result and this map can be
 * merged and deduped.
 */
const EXPANSION_MAP: Record<string, string[]> = {
  "hair stylist": [
    "hairdresser", "salon", "hair salon", "beauty salon", "silk press",
    "natural hair", "black hair salon", "curly hair", "hair extensions",
    "color specialist", "hair artist", "hair studio", "natural stylist",
    "master stylist", "cosmetologist",
  ],
  barber: ["barbershop", "fade specialist", "men's grooming", "beard trim", "haircut"],
  "lash tech": ["lash extensions", "lash artist", "russian volume lashes", "classic lashes", "lash lift"],
  "nail tech": ["nail salon", "manicure", "pedicure", "acrylic nails", "gel nails", "nail artist"],
  "makeup artist": ["mua", "bridal makeup", "glam makeup", "special occasion makeup"],
  esthetician: ["skincare specialist", "facials", "skin care", "chemical peel"],
  braider: ["braid stylist", "box braids", "knotless braids", "cornrows", "protective styles"],
  "loc specialist": ["loctician", "dreadlocks", "sisterlocks", "loc retwist"],
  "wig installer": ["wig specialist", "lace front install", "wig customization"],
  "hair colorist": ["balayage", "color specialist", "highlights", "hair color"],
  "hair extension specialist": ["hair extensions", "tape-in extensions", "sew-in specialist"],
  waxing: ["wax studio", "brazilian wax", "hair removal"],
  sugaring: ["sugar wax", "organic hair removal"],
  "permanent makeup": ["cosmetic tattoo", "microblading", "lip blush"],
  microblading: ["eyebrow microblading", "permanent makeup", "brow artist"],
  "massage therapist": ["massage studio", "deep tissue massage", "spa massage"],
  "facial specialist": ["facials", "esthetician", "skincare"],
  "med spa": ["medspa", "botox", "aesthetics clinic", "injectables"],
  "spray tan": ["airbrush tan", "sunless tanning", "tanning studio"],
  "teeth whitening": ["smile studio", "cosmetic teeth whitening"],
  "tattoo artist": ["tattoo studio", "tattoo shop", "custom tattoo"],
  "piercing studio": ["piercer", "body piercing"],
};

export function expandSearchTerm(term: string): string[] {
  const key = term.trim().toLowerCase();
  const direct = EXPANSION_MAP[key];
  if (direct) return [term, ...direct];

  // Loose match: if the typed term contains a known key (e.g. "silk press stylist"),
  // pull in that category's expansions too.
  for (const [k, v] of Object.entries(EXPANSION_MAP)) {
    if (key.includes(k) || k.includes(key)) {
      return [term, ...v];
    }
  }

  // Freeform query the user typed themselves (e.g. "Russian volume lash tech") —
  // pass it through as-is; the AI expansion call (when enabled) handles these.
  return [term];
}
