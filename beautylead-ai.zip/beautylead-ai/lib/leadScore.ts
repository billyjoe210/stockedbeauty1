import { Business } from "@/lib/types";

/**
 * Computes a 0–100 Lead Score from the signals listed in the product spec:
 * review rating, review count, website quality, Instagram activity, recent
 * posts, business age, photos, response rate, open now, verified business,
 * social engagement. Each factor is capped so no single signal dominates.
 */
export function computeLeadScore(b: Business): { score: number; breakdown: Record<string, number> } {
  const breakdown: Record<string, number> = {};

  breakdown.rating = clamp(((b.rating ?? 0) / 5) * 25, 0, 25);
  breakdown.reviewVolume = clamp(Math.log10((b.reviewCount ?? 0) + 1) * 8, 0, 15);
  breakdown.website = b.website ? 10 : 0;
  breakdown.instagram = b.instagram ? 8 : 0;
  breakdown.recentActivity =
    b.lastPostDaysAgo === undefined ? 0 : clamp(15 - b.lastPostDaysAgo / 2, 0, 15);
  breakdown.businessAge = clamp((b.yearsInBusiness ?? 0) * 1.2, 0, 10);
  breakdown.photos = clamp((b.photos?.length ?? 0) * 2, 0, 6);
  breakdown.openNow = b.openNow ? 4 : 0;
  breakdown.verified = b.verified ? 7 : 0;
  breakdown.socialEngagement = b.facebook ? 5 : 0;

  const total = Object.values(breakdown).reduce((a, c) => a + c, 0);
  return { score: Math.round(clamp(total, 0, 100)), breakdown };
}

function clamp(n: number, min: number, max: number) {
  return Math.max(min, Math.min(max, n));
}
