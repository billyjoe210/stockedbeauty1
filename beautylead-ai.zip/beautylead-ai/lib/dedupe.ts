import { Business } from "@/lib/types";

/**
 * Merges duplicate businesses returned by multiple providers (e.g. the same
 * salon found on both Google and Yelp) by matching on normalized name +
 * street number. Merges sources and fills in missing fields rather than
 * dropping data.
 */
export function dedupeBusinesses(businesses: Business[]): Business[] {
  const map = new Map<string, Business>();

  for (const b of businesses) {
    const key = normalizeKey(b);
    const existing = map.get(key);
    if (!existing) {
      map.set(key, { ...b });
      continue;
    }
    map.set(key, {
      ...existing,
      ...compactMerge(existing, b),
      sources: Array.from(new Set([...existing.sources, ...b.sources])),
    });
  }

  return Array.from(map.values());
}

function normalizeKey(b: Business): string {
  const name = b.name.toLowerCase().replace(/[^a-z0-9]/g, "");
  const streetNumber = b.address.match(/^\d+/)?.[0] ?? "";
  return `${name}-${streetNumber}`;
}

function compactMerge(a: Business, b: Business): Partial<Business> {
  const out: Partial<Business> = {};
  const keys: (keyof Business)[] = [
    "ownerName", "phone", "website", "instagram", "facebook", "email",
    "hours", "yearsInBusiness", "photos",
  ];
  for (const k of keys) {
    // @ts-expect-error - generic passthrough merge
    out[k] = a[k] ?? b[k];
  }
  out.rating = Math.max(a.rating ?? 0, b.rating ?? 0) || undefined;
  out.reviewCount = (a.reviewCount ?? 0) + (b.reviewCount ?? 0) || undefined;
  return out;
}
