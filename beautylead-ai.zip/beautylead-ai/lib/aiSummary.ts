import { Business } from "@/lib/types";

const OPENAI_KEY = process.env.OPENAI_API_KEY;

/**
 * Generates a one or two sentence summary per business, e.g.
 * "Specializes in natural hair and silk presses. Highly rated with over
 * 450 reviews. Active on Instagram and recently posted within the last week."
 *
 * When OPENAI_API_KEY is set, swap the template below for a real call:
 *
 * const res = await fetch("https://api.openai.com/v1/chat/completions", {
 *   method: "POST",
 *   headers: { Authorization: `Bearer ${OPENAI_KEY}`, "Content-Type": "application/json" },
 *   body: JSON.stringify({
 *     model: "gpt-4o-mini",
 *     messages: [{ role: "user", content: buildSummaryPrompt(b) }],
 *   }),
 * });
 */
export function generateSummary(b: Business): string {
  const parts: string[] = [];
  parts.push(`Specializes in ${b.category.toLowerCase()}.`);
  if (b.rating && b.reviewCount) {
    parts.push(
      `${b.rating >= 4.5 ? "Highly rated" : "Rated"} with ${b.reviewCount > 100 ? "over " : ""}${roundReviews(
        b.reviewCount
      )} reviews.`
    );
  }
  if (b.instagram) {
    parts.push(
      b.lastPostDaysAgo !== undefined && b.lastPostDaysAgo <= 7
        ? "Active on Instagram and recently posted within the last week."
        : "Active on Instagram."
    );
  }
  if (b.yearsInBusiness && b.yearsInBusiness >= 5) {
    parts.push(`Established ${b.yearsInBusiness} years in business.`);
  }
  return parts.join(" ");
}

function roundReviews(n: number): number {
  if (n > 100) return Math.floor(n / 50) * 50;
  return n;
}

export interface Insight {
  label: string;
  businessId: string;
}

/**
 * Generates headline insights across the result set, e.g.
 * "Most highly rated lash artist within 10 miles", "Best value stylist".
 */
export function generateInsights(results: Business[], service: string): Insight[] {
  if (results.length === 0) return [];
  const insights: Insight[] = [];

  const byRating = [...results].sort((a, b) => (b.rating ?? 0) - (a.rating ?? 0))[0];
  if (byRating) insights.push({ label: `Most highly rated ${service.toLowerCase()} nearby`, businessId: byRating.id });

  const byValue = [...results].sort(
    (a, b) => (b.rating ?? 0) / ((b.attributes?.priceTier === "luxury" ? 3 : b.attributes?.priceTier === "mid" ? 2 : 1)) -
      (a.rating ?? 0) / ((a.attributes?.priceTier === "luxury" ? 3 : a.attributes?.priceTier === "mid" ? 2 : 1))
  )[0];
  if (byValue) insights.push({ label: "Best value pick", businessId: byValue.id });

  const byGrowth = [...results].sort((a, b) => (a.lastPostDaysAgo ?? 99) - (b.lastPostDaysAgo ?? 99))[0];
  if (byGrowth) insights.push({ label: "Most active on Instagram", businessId: byGrowth.id });

  const newest = [...results].sort((a, b) => (a.yearsInBusiness ?? 99) - (b.yearsInBusiness ?? 99))[0];
  if (newest) insights.push({ label: "Newest on the scene", businessId: newest.id });

  const luxury = results.find((r) => r.attributes?.priceTier === "luxury");
  if (luxury) insights.push({ label: "Luxury recommendation", businessId: luxury.id });

  return insights;
}
