import { Provider } from "./types";
import { generateMockBusinesses } from "./mockDataGenerator";

const API_KEY = process.env.GOOGLE_CSE_API_KEY;
const CSE_ID = process.env.GOOGLE_CSE_ID;

export const websearchProvider: Provider = {
  id: "websearch",
  label: "Searching websites...",
  enabled: true, // MVP provider — finds independent business sites Maps/Yelp miss
  async search({ service, location }) {
    if (!API_KEY || !CSE_ID) {
      return generateMockBusinesses(service, location, "websearch", 4);
    }

    // Real integration (Google Custom Search JSON API):
    // const q = `${service} ${location} salon OR studio`;
    // const url = `https://www.googleapis.com/customsearch/v1?key=${API_KEY}&cx=${CSE_ID}&q=${encodeURIComponent(q)}`;
    // const res = await fetch(url);
    // const data = await res.json();
    // return data.items?.map(normalizeSearchResult) ?? [];

    return generateMockBusinesses(service, location, "websearch", 4);
  },
};
