import { Business } from "@/lib/types";
import { Provider } from "./types";
import { generateMockBusinesses } from "./mockDataGenerator";

const API_KEY = process.env.GOOGLE_MAPS_API_KEY;

export const googleProvider: Provider = {
  id: "google",
  label: "Searching Google Maps...",
  enabled: true, // MVP provider — always on, falls back to mock data if no key
  async search({ service, location, expandedTerms }) {
    if (!API_KEY) {
      // No credentials configured yet — return sample data so the product
      // experience works end to end. Swap this block for the real call below.
      return generateMockBusinesses(service, location, "google", 8);
    }

    // Real integration (Google Places API — Text Search):
    // const query = `${service} near ${location}`;
    // const url = `https://maps.googleapis.com/maps/api/place/textsearch/json?query=${encodeURIComponent(
    //   query
    // )}&key=${API_KEY}`;
    // const res = await fetch(url);
    // const data = await res.json();
    // return data.results.map(normalizeGooglePlace);

    return generateMockBusinesses(service, location, "google", 8);
  },
};

// function normalizeGooglePlace(place: any): Business {
//   return {
//     id: `google-${place.place_id}`,
//     name: place.name,
//     category: place.types?.[0] ?? "Beauty",
//     address: place.formatted_address,
//     rating: place.rating,
//     reviewCount: place.user_ratings_total,
//     lat: place.geometry?.location?.lat,
//     lng: place.geometry?.location?.lng,
//     openNow: place.opening_hours?.open_now,
//     sources: ["google"],
//   };
// }
