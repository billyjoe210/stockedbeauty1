import { Business, ProviderId, SearchRequest } from "@/lib/types";

/**
 * Every data source (Google, Yelp, Instagram, Facebook, Eventbrite, Bing,
 * OSM, web search, ...) implements this same contract and returns the same
 * normalized Business[] shape. This is what makes the system modular:
 * adding a new source is "write one file that implements Provider",
 * nothing else in the app needs to change.
 */
export interface Provider {
  id: ProviderId;
  label: string; // shown in the progress animation, e.g. "Searching Yelp..."
  enabled: boolean; // feature flag — disabled providers are skipped, never break the search
  search(req: SearchRequest & { expandedTerms: string[] }): Promise<Business[]>;
}

/**
 * Wraps a provider call so that a failing or disabled provider (rate limit,
 * missing credentials, API outage) never breaks the overall search —
 * it just contributes zero results. This is the "fail gracefully" requirement.
 */
export async function runProviderSafely(provider: Provider, req: Parameters<Provider["search"]>[0]): Promise<Business[]> {
  if (!provider.enabled) return [];
  try {
    return await provider.search(req);
  } catch (err) {
    console.error(`[provider:${provider.id}] failed`, err);
    return [];
  }
}
