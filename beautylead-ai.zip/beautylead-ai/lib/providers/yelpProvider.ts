import { Provider } from "./types";
import { generateMockBusinesses } from "./mockDataGenerator";

const API_KEY = process.env.YELP_API_KEY;

export const yelpProvider: Provider = {
  id: "yelp",
  label: "Searching Yelp...",
  enabled: true, // MVP provider
  async search({ service, location }) {
    if (!API_KEY) {
      return generateMockBusinesses(service, location, "yelp", 6);
    }

    // Real integration (Yelp Fusion API — Business Search):
    // const url = `https://api.yelp.com/v3/businesses/search?term=${encodeURIComponent(
    //   service
    // )}&location=${encodeURIComponent(location)}&categories=beautysvc`;
    // const res = await fetch(url, { headers: { Authorization: `Bearer ${API_KEY}` } });
    // const data = await res.json();
    // return data.businesses.map(normalizeYelpBusiness);

    return generateMockBusinesses(service, location, "yelp", 6);
  },
};

// function normalizeYelpBusiness(b: any): Business {
//   return {
//     id: `yelp-${b.id}`,
//     name: b.name,
//     category: b.categories?.[0]?.title ?? "Beauty",
//     address: b.location?.display_address?.join(", "),
//     phone: b.display_phone,
//     rating: b.rating,
//     reviewCount: b.review_count,
//     website: b.url,
//     lat: b.coordinates?.latitude,
//     lng: b.coordinates?.longitude,
//     photos: b.photos,
//     sources: ["yelp"],
//   };
// }
