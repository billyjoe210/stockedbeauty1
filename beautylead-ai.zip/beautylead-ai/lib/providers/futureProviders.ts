import { Provider } from "./types";

/**
 * These providers implement the same Provider contract as google/yelp/websearch
 * but stay disabled until API credentials + platform permissions are in place.
 * Flip `enabled: true` (and set the matching env var) to bring one online —
 * no other part of the app needs to change.
 */

export const instagramProvider: Provider = {
  id: "instagram",
  label: "Searching Instagram...",
  enabled: process.env.FEATURE_INSTAGRAM === "true",
  async search() {
    // Requires Instagram Graph API access (Business/Creator accounts only).
    return [];
  },
};

export const facebookProvider: Provider = {
  id: "facebook",
  label: "Searching Facebook Pages...",
  enabled: process.env.FEATURE_FACEBOOK === "true",
  async search() {
    // Requires Facebook Pages API access.
    return [];
  },
};

export const eventbriteProvider: Provider = {
  id: "eventbrite",
  label: "Searching Eventbrite...",
  enabled: process.env.FEATURE_EVENTBRITE === "true",
  async search() {
    // Requires Eventbrite API key — surfaces pop-up/event-based beauty pros.
    return [];
  },
};

export const bingProvider: Provider = {
  id: "bing",
  label: "Searching Bing...",
  enabled: process.env.FEATURE_BING === "true",
  async search() {
    // Requires Bing Search API key.
    return [];
  },
};

export const osmProvider: Provider = {
  id: "osm",
  label: "Searching OpenStreetMap...",
  enabled: process.env.FEATURE_OSM === "true",
  async search() {
    // OpenStreetMap Nominatim / Overpass API — no key required, but off by
    // default for MVP scope.
    return [];
  },
};
