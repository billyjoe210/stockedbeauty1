import { Business, ProviderId } from "@/lib/types";

// Deterministic pseudo-random so the same search returns stable results
function seededRandom(seed: number) {
  let s = seed;
  return () => {
    s = (s * 9301 + 49297) % 233280;
    return s / 233280;
  };
}

const FIRST_NAMES = ["Jasmine", "Amara", "Nia", "Camille", "Destiny", "Priya", "Elena", "Marcus", "Andre", "Sofia", "Tasha", "Rochelle"];
const STUDIO_WORDS = ["Studio", "Collective", "Beauty Bar", "Salon", "House of Beauty", "Lounge", "Atelier", "Room"];

function pick<T>(arr: T[], rnd: () => number): T {
  return arr[Math.floor(rnd() * arr.length)];
}

/**
 * Generates realistic-looking, clearly-labeled sample businesses for a given
 * service + location. This stands in for a live API response so the product
 * experience can be demoed end-to-end before real credentials (Google Places
 * API key, Yelp Fusion key, etc.) are wired in — see README for how to swap
 * this out per-provider.
 */
export function generateMockBusinesses(
  service: string,
  location: string,
  provider: ProviderId,
  count: number
): Business[] {
  const seedBase = hashString(`${service}|${location}|${provider}`);
  const rnd = seededRandom(seedBase);
  const results: Business[] = [];

  for (let i = 0; i < count; i++) {
    const first = pick(FIRST_NAMES, rnd);
    const word = pick(STUDIO_WORDS, rnd);
    const name = `${first}'s ${capitalize(service)} ${word}`;
    const rating = Math.round((3.5 + rnd() * 1.5) * 10) / 10;
    const reviewCount = Math.floor(8 + rnd() * 600);
    const yearsInBusiness = Math.floor(1 + rnd() * 12);
    const lastPostDaysAgo = Math.floor(rnd() * 30);
    const distanceMiles = Math.round((rnd() * 24 + 0.3) * 10) / 10;

    results.push({
      id: `${provider}-${seedBase}-${i}`,
      name,
      ownerName: rnd() > 0.4 ? `${first} ${pick(["Reed", "Coleman", "Vasquez", "Whitfield", "Okafor", "Nguyen"], rnd)}` : undefined,
      category: capitalize(service),
      address: `${100 + Math.floor(rnd() * 8000)} ${pick(["Main St", "Charles St", "Falls Rd", "North Ave", "Fayette St", "Reisterstown Rd"], rnd)}, ${location}`,
      distanceMiles,
      phone: `(${400 + Math.floor(rnd() * 500)}) 555-${1000 + Math.floor(rnd() * 8999)}`,
      website: rnd() > 0.25 ? `https://${slugify(name)}.com` : undefined,
      instagram: rnd() > 0.15 ? `https://instagram.com/${slugify(name)}` : undefined,
      facebook: rnd() > 0.5 ? `https://facebook.com/${slugify(name)}` : undefined,
      email: rnd() > 0.5 ? `hello@${slugify(name)}.com` : undefined,
      rating,
      reviewCount,
      hours: pick(["Tue–Sat 9am–6pm", "Mon–Fri 10am–7pm", "Wed–Sun 9am–5pm", "By appointment"], rnd),
      openNow: rnd() > 0.4,
      yearsInBusiness,
      photos: [],
      lat: 39.29 + (rnd() - 0.5) * 0.3,
      lng: -76.61 + (rnd() - 0.5) * 0.3,
      verified: rnd() > 0.6,
      attributes: {
        blackOwned: rnd() > 0.5,
        womenOwned: rnd() > 0.4,
        spanishSpeaking: rnd() > 0.7,
        kidFriendly: rnd() > 0.6,
        wheelchairAccessible: rnd() > 0.5,
        onlineBooking: rnd() > 0.3,
        walkIns: rnd() > 0.5,
        mobileService: rnd() > 0.8,
        priceTier: pick(["budget", "mid", "luxury"], rnd) as "budget" | "mid" | "luxury",
        organicProducts: rnd() > 0.7,
        veganProducts: rnd() > 0.75,
        openWeekends: rnd() > 0.4,
        openLate: rnd() > 0.75,
      },
      sources: [provider],
      lastPostDaysAgo,
    });
  }

  return results;
}

function hashString(str: string): number {
  let hash = 0;
  for (let i = 0; i < str.length; i++) {
    hash = (hash << 5) - hash + str.charCodeAt(i);
    hash |= 0;
  }
  return Math.abs(hash) || 1;
}

function capitalize(s: string): string {
  return s.replace(/\b\w/g, (c) => c.toUpperCase());
}

function slugify(s: string): string {
  return s.toLowerCase().replace(/[^a-z0-9]+/g, "");
}
