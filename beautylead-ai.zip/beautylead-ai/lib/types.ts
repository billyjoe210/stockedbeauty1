export type ProviderId =
  | "google"
  | "yelp"
  | "instagram"
  | "facebook"
  | "eventbrite"
  | "bing"
  | "websearch"
  | "osm";

export interface Business {
  id: string;
  name: string;
  ownerName?: string;
  category: string;
  address: string;
  distanceMiles?: number;
  phone?: string;
  website?: string;
  instagram?: string;
  facebook?: string;
  email?: string;
  rating?: number;
  reviewCount?: number;
  hours?: string;
  openNow?: boolean;
  yearsInBusiness?: number;
  photos?: string[];
  lat?: number;
  lng?: number;
  verified?: boolean;
  attributes?: {
    blackOwned?: boolean;
    womenOwned?: boolean;
    spanishSpeaking?: boolean;
    kidFriendly?: boolean;
    wheelchairAccessible?: boolean;
    onlineBooking?: boolean;
    walkIns?: boolean;
    mobileService?: boolean;
    priceTier?: "budget" | "mid" | "luxury";
    organicProducts?: boolean;
    veganProducts?: boolean;
    openWeekends?: boolean;
    openLate?: boolean;
  };
  sources: ProviderId[];
  lastPostDaysAgo?: number;
  summary?: string;
  leadScore?: number;
  leadScoreBreakdown?: Record<string, number>;
}

export interface SearchRequest {
  service: string;
  location: string;
}

export interface SearchProgressEvent {
  step: string;
  done: boolean;
}

export interface ProviderResult {
  provider: ProviderId;
  businesses: Business[];
}

export interface SearchFilters {
  distance?: number;
  minRating?: number;
  openNow?: boolean;
  blackOwned?: boolean;
  womenOwned?: boolean;
  spanishSpeaking?: boolean;
  kidFriendly?: boolean;
  wheelchairAccessible?: boolean;
  onlineBooking?: boolean;
  walkIns?: boolean;
  mobileService?: boolean;
  priceTier?: "budget" | "mid" | "luxury";
  organicProducts?: boolean;
  veganProducts?: boolean;
  openWeekends?: boolean;
  openLate?: boolean;
}
