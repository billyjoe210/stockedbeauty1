import type { Config } from "tailwindcss";

const config: Config = {
  content: [
    "./app/**/*.{ts,tsx}",
    "./components/**/*.{ts,tsx}",
  ],
  theme: {
    extend: {
      colors: {
        paper: "#FAF8F5",
        ink: "#1C1815",
        muted: "#6F675F",
        line: "#E7E1D8",
        berry: {
          DEFAULT: "#A8305A",
          50: "#FBEEF1",
          100: "#F4D3DD",
          400: "#C25679",
          500: "#A8305A",
          600: "#8A2249",
          700: "#6C1938",
        },
        gold: {
          DEFAULT: "#B4922E",
          100: "#F3E9CE",
          400: "#C9A83F",
          500: "#B4922E",
        },
        sage: {
          DEFAULT: "#6F8267",
          100: "#E3E9DF",
          500: "#6F8267",
        },
      },
      fontFamily: {
        display: ["var(--font-display)"],
        body: ["var(--font-body)"],
      },
      borderRadius: {
        xl2: "1.25rem",
      },
      boxShadow: {
        card: "0 1px 2px rgba(28,24,21,0.04), 0 8px 24px -12px rgba(28,24,21,0.12)",
        cardHover: "0 4px 8px rgba(28,24,21,0.06), 0 16px 32px -12px rgba(28,24,21,0.18)",
      },
      keyframes: {
        pulseDot: {
          "0%, 100%": { opacity: "0.3" },
          "50%": { opacity: "1" },
        },
        rise: {
          "0%": { opacity: "0", transform: "translateY(8px)" },
          "100%": { opacity: "1", transform: "translateY(0)" },
        },
      },
      animation: {
        pulseDot: "pulseDot 1.4s ease-in-out infinite",
        rise: "rise 0.4s ease-out both",
      },
    },
  },
  plugins: [],
};
export default config;
