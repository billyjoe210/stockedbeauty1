# BeautyLead AI

Discover beauty professionals and salons by aggregating public information
from multiple sources (Google Maps, Yelp, business websites, and more) into
one fast, searchable interface.

This is the **v1 MVP** described in the product spec: service selection →
location → animated multi-source search → ranked, filterable results with
an interactive map.

## Status of this build

This is a runnable Next.js app with the full MVP UI and a real provider
architecture. Because this environment has no network access and no API
keys configured, every provider currently **falls back to realistic mock
data** so you can see and click through the entire product today. Swap in
real credentials (see `.env.example`) and each provider will start hitting
the live API — no other code changes needed.

## Getting started

```bash
npm install
cp .env.example .env.local   # add real API keys when you have them
npm run dev
```

Open http://localhost:3000.

## Architecture

```
app/
  page.tsx                 Service + location selection (step 1 / step 2)
  search/page.tsx           Progress animation → filters, results, map
  api/search/route.ts       Orchestrates all providers, dedupes, scores, sorts

lib/
  types.ts                  Normalized Business data model shared by every provider
  searchExpansion.ts        "Hair Stylist" → also searches "Silk Press", "Natural Hair", ...
  dedupe.ts                 Merges the same salon found across multiple providers
  leadScore.ts              0–100 Lead Score from rating, reviews, activity, etc.
  aiSummary.ts               Per-business summaries + cross-result insights
                             (swap the template for a real OpenAI call — see comments)

  providers/
    types.ts                 Provider interface every data source implements
    googleProvider.ts         MVP — Google Places (mock fallback until GOOGLE_MAPS_API_KEY is set)
    yelpProvider.ts            MVP — Yelp Fusion (mock fallback until YELP_API_KEY is set)
    websearchProvider.ts       MVP — Google Custom Search for business websites
    futureProviders.ts         Instagram, Facebook, Eventbrite, Bing, OSM —
                                stubbed, disabled behind feature flags, ready to
                                enable without touching the rest of the app
    mockDataGenerator.ts       Deterministic sample data used by every provider
                                until its real API key is configured
```

### Adding a new data source

1. Create `lib/providers/yourProvider.ts` implementing the `Provider` interface
   (`id`, `label`, `enabled`, `search()`).
2. Return `Business[]` in the normalized shape from `lib/types.ts`.
3. Add it to the `ALL_PROVIDERS` array in `app/api/search/route.ts`.

That's it — search expansion, deduping, Lead Scoring, filtering, and the map
all work against the normalized shape automatically. A failing or
rate-limited provider never breaks the search: `runProviderSafely()` catches
errors and just contributes zero results.

## What's implemented (v1 MVP scope)

- Service selection (search + category grid) and location step
- Animated multi-source search progress
- Google Maps Places + Yelp Fusion + Google Custom Search provider scaffolding
- AI search term expansion (static map today, designed to be backed by an
  OpenAI call)
- Unified business cards with contact tools, tags, and Lead Score
- AI-generated summaries and cross-result insights ("Most highly rated",
  "Best value pick", ...)
- Filters (rating, distance, price, Black-owned, mobile service, etc.)
- Interactive map with color-coded pins synced to card selection
- Favorites (persisted locally) with CSV export

## What's scaffolded but disabled

Instagram, Facebook Pages, Eventbrite, Bing, and OpenStreetMap providers are
written against the same `Provider` interface and wired into the search
orchestration, but return no results until you set their feature flag to
`true` and supply credentials — matching the spec's requirement to leave the
framework in place without shipping half-working integrations.

## Next steps toward production

- Add Postgres + Prisma for persistent users, saved lists, and cached provider
  responses (schema intentionally left out of this pass — see Tech Stack in
  the spec for the intended shape: `businesses`, `providers`, `searches`,
  `favorites`, `folders`).
- Add Redis for response caching and provider rate-limit tracking.
- Swap `lib/aiSummary.ts` and `lib/searchExpansion.ts` templates for real
  OpenAI calls (prompts are drafted in code comments).
- Add Google/Facebook/email auth (NextAuth.js is a natural fit) — currently
  the app runs in guest mode only, as allowed for v1.
- Replace `MapView`'s SVG placeholder with Mapbox GL or Google Maps once an
  API key is available; pin/selection wiring is already in place.
