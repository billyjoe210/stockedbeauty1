import Link from "next/link";

export function Header() {
  return (
    <header className="border-b border-line">
      <div className="container-lead flex h-16 items-center justify-between">
        <Link href="/" className="flex items-center gap-2">
          <span className="flex h-7 w-7 items-center justify-center rounded-full border border-berry text-berry">
            <span className="font-display italic text-[15px] leading-none">b</span>
          </span>
          <span className="font-display text-lg tracking-tight">BeautyLead <span className="italic text-berry">AI</span></span>
        </Link>
        <nav className="hidden items-center gap-6 text-sm text-muted sm:flex">
          <Link href="/" className="hover:text-ink">New search</Link>
          <span className="text-line">|</span>
          <span>Guest mode</span>
        </nav>
      </div>
    </header>
  );
}
