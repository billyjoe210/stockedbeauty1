"use client";

const CATEGORIES = [
  "Hair Stylist", "Barber", "Lash Tech", "Nail Tech", "Makeup Artist",
  "Esthetician", "Braider", "Loc Specialist", "Wig Installer", "Hair Colorist",
  "Hair Extension Specialist", "Waxing", "Sugaring", "Permanent Makeup",
  "Microblading", "Massage Therapist", "Facial Specialist", "Med Spa",
  "Spray Tan", "Teeth Whitening", "Tattoo Artist", "Piercing Studio",
];

export function CategoryGrid({ onSelect, selected }: { onSelect: (c: string) => void; selected: string }) {
  return (
    <div className="grid grid-cols-2 gap-2 sm:grid-cols-3 md:grid-cols-4">
      {CATEGORIES.map((c) => {
        const active = c.toLowerCase() === selected.toLowerCase();
        return (
          <button
            key={c}
            onClick={() => onSelect(c)}
            className={`rounded-full border px-4 py-2.5 text-sm transition-all ${
              active
                ? "border-berry bg-berry text-white shadow-card"
                : "border-line bg-white text-ink hover:border-berry-400 hover:text-berry-600"
            }`}
          >
            {c}
          </button>
        );
      })}
    </div>
  );
}
