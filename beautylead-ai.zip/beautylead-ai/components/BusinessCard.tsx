"use client";

import { Business } from "@/lib/types";
import {
  Phone, Globe, Instagram, Facebook, Mail, MapPinned, Share2, Copy, Heart, Star, BadgeCheck,
} from "lucide-react";

function ScoreRing({ score }: { score: number }) {
  const r = 20;
  const c = 2 * Math.PI * r;
  const offset = c - (score / 100) * c;
  const color = score >= 80 ? "#6F8267" : score >= 60 ? "#B4922E" : "#A8305A";
  return (
    <div className="relative flex h-14 w-14 shrink-0 items-center justify-center">
      <svg width="56" height="56" viewBox="0 0 56 56" className="-rotate-90">
        <circle cx="28" cy="28" r={r} stroke="#E7E1D8" strokeWidth="4" fill="none" />
        <circle
          cx="28" cy="28" r={r} stroke={color} strokeWidth="4" fill="none"
          strokeDasharray={c} strokeDashoffset={offset} strokeLinecap="round"
        />
      </svg>
      <span className="absolute font-display text-sm">{score}</span>
    </div>
  );
}

export function BusinessCard({
  business, onSelect, selected, isFavorite, onToggleFavorite,
}: {
  business: Business;
  onSelect: () => void;
  selected: boolean;
  isFavorite: boolean;
  onToggleFavorite: () => void;
}) {
  const b = business;

  function copyContact() {
    const text = [b.name, b.phone, b.email, b.website].filter(Boolean).join(" · ");
    navigator.clipboard?.writeText(text);
  }

  return (
    <div
      onClick={onSelect}
      className={`cursor-pointer rounded-xl2 border bg-white p-5 transition-all hover:shadow-cardHover ${
        selected ? "border-berry shadow-cardHover" : "border-line shadow-card"
      }`}
    >
      <div className="flex items-start justify-between gap-3">
        <div className="flex items-start gap-3">
          <ScoreRing score={b.leadScore ?? 0} />
          <div>
            <div className="flex items-center gap-1.5">
              <h3 className="font-display text-lg leading-tight">{b.name}</h3>
              {b.verified && <BadgeCheck className="h-4 w-4 text-sage" />}
            </div>
            <p className="text-sm text-muted">{b.category}{b.ownerName ? ` · ${b.ownerName}` : ""}</p>
            <div className="mt-1 flex items-center gap-2 text-sm">
              {b.rating && (
                <span className="flex items-center gap-1 text-gold-500">
                  <Star className="h-3.5 w-3.5 fill-gold-500" /> {b.rating}
                  <span className="text-muted">({b.reviewCount})</span>
                </span>
              )}
              {b.distanceMiles !== undefined && <span className="text-muted">{b.distanceMiles} mi</span>}
              {b.openNow && <span className="text-sage-500">Open now</span>}
            </div>
          </div>
        </div>
        <button
          onClick={(e) => { e.stopPropagation(); onToggleFavorite(); }}
          className={`shrink-0 rounded-full p-1.5 transition-colors ${isFavorite ? "text-berry" : "text-muted hover:text-berry"}`}
          aria-label="Save favorite"
        >
          <Heart className={`h-5 w-5 ${isFavorite ? "fill-berry" : ""}`} />
        </button>
      </div>

      {b.summary && <p className="mt-3 text-sm leading-relaxed text-ink/80">{b.summary}</p>}

      <p className="mt-3 text-xs text-muted">{b.address}</p>

      <div className="mt-4 flex flex-wrap items-center gap-1.5">
        {(["blackOwned", "womenOwned", "mobileService", "onlineBooking"] as const).map((k) =>
          b.attributes?.[k] ? (
            <span key={k} className="rounded-full bg-sage-100 px-2.5 py-1 text-[11px] font-medium text-sage-500">
              {labelFor(k)}
            </span>
          ) : null
        )}
      </div>

      <div className="mt-4 flex items-center gap-1 border-t border-line pt-3" onClick={(e) => e.stopPropagation()}>
        {b.phone && <IconLink href={`tel:${b.phone}`} icon={Phone} label="Call" />}
        {b.website && <IconLink href={b.website} icon={Globe} label="Website" />}
        {b.instagram && <IconLink href={b.instagram} icon={Instagram} label="Instagram" />}
        {b.facebook && <IconLink href={b.facebook} icon={Facebook} label="Facebook" />}
        {b.email && <IconLink href={`mailto:${b.email}`} icon={Mail} label="Email" />}
        <IconLink href={`https://maps.google.com/?q=${encodeURIComponent(b.address)}`} icon={MapPinned} label="Directions" />
        <button onClick={copyContact} className="rounded-full p-2 text-muted hover:bg-paper hover:text-ink" title="Copy contact">
          <Copy className="h-4 w-4" />
        </button>
        <button
          onClick={() => navigator.share?.({ title: b.name, text: b.summary, url: b.website })}
          className="rounded-full p-2 text-muted hover:bg-paper hover:text-ink"
          title="Share"
        >
          <Share2 className="h-4 w-4" />
        </button>
      </div>
    </div>
  );
}

function IconLink({ href, icon: Icon, label }: { href: string; icon: any; label: string }) {
  return (
    <a href={href} target="_blank" rel="noreferrer" className="rounded-full p-2 text-muted hover:bg-paper hover:text-ink" title={label}>
      <Icon className="h-4 w-4" />
    </a>
  );
}

function labelFor(k: string) {
  return { blackOwned: "Black-owned", womenOwned: "Women-owned", mobileService: "Mobile service", onlineBooking: "Online booking" }[k] ?? k;
}
