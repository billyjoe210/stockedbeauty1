"use client";

import { Business } from "@/lib/types";
import { useMemo } from "react";

/**
 * Lightweight SVG map placeholder that plots real business lat/lng on a
 * normalized grid, color-coded by Lead Score, with click-to-select syncing
 * to the card list. Swap the <svg> body for a <Map> from react-map-gl
 * (Mapbox) or @vis.gl/react-google-maps once an API key is configured —
 * the selection/highlight wiring below stays the same either way.
 */
export function MapView({
  businesses, selectedId, onSelect,
}: {
  businesses: Business[];
  selectedId: string | null;
  onSelect: (id: string) => void;
}) {
  const points = useMemo(() => {
    const withCoords = businesses.filter((b) => b.lat !== undefined && b.lng !== undefined);
    if (withCoords.length === 0) return [];
    const lats = withCoords.map((b) => b.lat!);
    const lngs = withCoords.map((b) => b.lng!);
    const minLat = Math.min(...lats), maxLat = Math.max(...lats);
    const minLng = Math.min(...lngs), maxLng = Math.max(...lngs);
    const pad = 40;
    return withCoords.map((b) => {
      const x = pad + ((b.lng! - minLng) / (maxLng - minLng || 1)) * (400 - pad * 2);
      const y = pad + (1 - (b.lat! - minLat) / (maxLat - minLat || 1)) * (320 - pad * 2);
      return { b, x, y };
    });
  }, [businesses]);

  function colorFor(score: number) {
    if (score >= 80) return "#6F8267";
    if (score >= 60) return "#B4922E";
    return "#A8305A";
  }

  return (
    <div className="sticky top-6 overflow-hidden rounded-xl2 border border-line bg-white">
      <svg viewBox="0 0 400 320" className="h-[320px] w-full bg-[#F3EFE8]">
        <defs>
          <pattern id="grid" width="20" height="20" patternUnits="userSpaceOnUse">
            <path d="M 20 0 L 0 0 0 20" fill="none" stroke="#E7E1D8" strokeWidth="1" />
          </pattern>
        </defs>
        <rect width="400" height="320" fill="url(#grid)" />
        {points.map(({ b, x, y }) => {
          const selected = b.id === selectedId;
          return (
            <g key={b.id} onClick={() => onSelect(b.id)} className="cursor-pointer">
              {selected && <circle cx={x} cy={y} r={12} fill={colorFor(b.leadScore ?? 0)} opacity={0.2} />}
              <circle
                cx={x} cy={y} r={selected ? 7 : 5.5}
                fill={colorFor(b.leadScore ?? 0)}
                stroke="white" strokeWidth={selected ? 2.5 : 1.5}
              />
            </g>
          );
        })}
      </svg>
      <div className="flex items-center gap-3 border-t border-line px-3 py-2 text-[11px] text-muted">
        <LegendDot color="#6F8267" label="80+" />
        <LegendDot color="#B4922E" label="60–79" />
        <LegendDot color="#A8305A" label="&lt;60" />
      </div>
    </div>
  );
}

function LegendDot({ color, label }: { color: string; label: string }) {
  return (
    <span className="flex items-center gap-1">
      <span className="h-2 w-2 rounded-full" style={{ background: color }} />
      {label}
    </span>
  );
}
