"use client";

import { SearchFilters } from "@/lib/types";

const TOGGLES: { key: keyof SearchFilters; label: string }[] = [
  { key: "openNow", label: "Open now" },
  { key: "blackOwned", label: "Black-owned" },
  { key: "womenOwned", label: "Women-owned" },
  { key: "spanishSpeaking", label: "Spanish speaking" },
  { key: "kidFriendly", label: "Kid friendly" },
  { key: "wheelchairAccessible", label: "Wheelchair accessible" },
  { key: "onlineBooking", label: "Accepts online booking" },
  { key: "walkIns", label: "Accepts walk-ins" },
  { key: "mobileService", label: "Mobile service" },
  { key: "organicProducts", label: "Organic products" },
  { key: "veganProducts", label: "Vegan products" },
  { key: "openWeekends", label: "Open weekends" },
  { key: "openLate", label: "Open late" },
];

const PRICE_TIERS = ["budget", "mid", "luxury"] as const;

export function FilterPanel({
  filters, onChange, resultCount,
}: {
  filters: SearchFilters;
  onChange: (f: SearchFilters) => void;
  resultCount: number;
}) {
  function toggle(key: keyof SearchFilters) {
    onChange({ ...filters, [key]: !filters[key] });
  }

  return (
    <div className="rounded-xl2 border border-line bg-white p-5">
      <div className="mb-4 flex items-center justify-between">
        <h3 className="font-display text-base">Filters</h3>
        <span className="text-xs text-muted">{resultCount} results</span>
      </div>

      <div className="mb-5">
        <label className="mb-1.5 block text-xs font-medium text-muted">Min. rating</label>
        <div className="flex gap-1.5">
          {[3, 3.5, 4, 4.5].map((r) => (
            <button
              key={r}
              onClick={() => onChange({ ...filters, minRating: filters.minRating === r ? undefined : r })}
              className={`rounded-full border px-2.5 py-1 text-xs ${
                filters.minRating === r ? "border-berry bg-berry text-white" : "border-line text-muted hover:border-berry-400"
              }`}
            >
              {r}+
            </button>
          ))}
        </div>
      </div>

      <div className="mb-5">
        <label className="mb-1.5 block text-xs font-medium text-muted">Distance</label>
        <div className="flex gap-1.5">
          {[5, 10, 25, 50].map((d) => (
            <button
              key={d}
              onClick={() => onChange({ ...filters, distance: filters.distance === d ? undefined : d })}
              className={`rounded-full border px-2.5 py-1 text-xs ${
                filters.distance === d ? "border-berry bg-berry text-white" : "border-line text-muted hover:border-berry-400"
              }`}
            >
              {d} mi
            </button>
          ))}
        </div>
      </div>

      <div className="mb-5">
        <label className="mb-1.5 block text-xs font-medium text-muted">Price</label>
        <div className="flex gap-1.5">
          {PRICE_TIERS.map((p) => (
            <button
              key={p}
              onClick={() => onChange({ ...filters, priceTier: filters.priceTier === p ? undefined : p })}
              className={`rounded-full border px-2.5 py-1 text-xs capitalize ${
                filters.priceTier === p ? "border-berry bg-berry text-white" : "border-line text-muted hover:border-berry-400"
              }`}
            >
              {p}
            </button>
          ))}
        </div>
      </div>

      <div>
        <label className="mb-1.5 block text-xs font-medium text-muted">More</label>
        <div className="flex flex-col gap-1.5">
          {TOGGLES.map((t) => (
            <label key={t.key} className="flex cursor-pointer items-center gap-2 text-sm">
              <input
                type="checkbox"
                checked={Boolean(filters[t.key])}
                onChange={() => toggle(t.key)}
                className="h-3.5 w-3.5 rounded border-line accent-berry"
              />
              {t.label}
            </label>
          ))}
        </div>
      </div>

      {Object.keys(filters).length > 0 && (
        <button onClick={() => onChange({})} className="mt-5 text-xs text-berry hover:underline">
          Clear all filters
        </button>
      )}
    </div>
  );
}
