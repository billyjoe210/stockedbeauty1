"use client";

import { useEffect, useState } from "react";
import { Check } from "lucide-react";

const STEPS = [
  "Searching Google Maps...",
  "Searching Yelp...",
  "Searching websites...",
  "Searching business directories...",
  "Analyzing results...",
  "Finding contact information...",
  "Removing duplicates...",
  "Ranking businesses...",
];

export function ProgressSearch({ service, location }: { service: string; location: string }) {
  const [activeIndex, setActiveIndex] = useState(0);

  useEffect(() => {
    const interval = setInterval(() => {
      setActiveIndex((i) => (i < STEPS.length - 1 ? i + 1 : i));
    }, 380);
    return () => clearInterval(interval);
  }, []);

  return (
    <div className="mx-auto flex min-h-[60vh] max-w-md flex-col items-center justify-center text-center">
      <div className="mb-2 h-9 w-9 animate-spin rounded-full border-2 border-berry-100 border-t-berry" />
      <h2 className="mt-4 font-display text-2xl">
        Finding <span className="italic text-berry">{service}</span> pros near {location}
      </h2>
      <ul className="mt-8 w-full space-y-2.5 text-left">
        {STEPS.map((step, i) => {
          const done = i < activeIndex;
          const active = i === activeIndex;
          return (
            <li key={step} className="flex items-center gap-3 text-sm">
              <span
                className={`flex h-5 w-5 shrink-0 items-center justify-center rounded-full border ${
                  done ? "border-sage bg-sage text-white" : active ? "border-berry" : "border-line"
                }`}
              >
                {done && <Check className="h-3 w-3" />}
                {active && !done && <span className="h-1.5 w-1.5 rounded-full bg-berry animate-pulseDot" />}
              </span>
              <span className={done ? "text-muted line-through decoration-line" : active ? "text-ink" : "text-muted/60"}>
                {step}
              </span>
            </li>
          );
        })}
      </ul>
    </div>
  );
}
