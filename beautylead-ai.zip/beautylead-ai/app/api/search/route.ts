import { NextRequest, NextResponse } from "next/server";
import { googleProvider } from "@/lib/providers/googleProvider";
import { yelpProvider } from "@/lib/providers/yelpProvider";
import { websearchProvider } from "@/lib/providers/websearchProvider";
import {
  instagramProvider,
  facebookProvider,
  eventbriteProvider,
  bingProvider,
  osmProvider,
} from "@/lib/providers/futureProviders";
import { runProviderSafely } from "@/lib/providers/types";
import { expandSearchTerm } from "@/lib/searchExpansion";
import { dedupeBusinesses } from "@/lib/dedupe";
import { computeLeadScore } from "@/lib/leadScore";
import { generateSummary } from "@/lib/aiSummary";

// MVP providers + future providers, all behind the same interface.
// Flip a future provider's `enabled` flag (see futureProviders.ts) and it
// joins the search automatically — no changes needed here.
const ALL_PROVIDERS = [
  googleProvider,
  yelpProvider,
  websearchProvider,
  instagramProvider,
  facebookProvider,
  eventbriteProvider,
  bingProvider,
  osmProvider,
];

export async function POST(req: NextRequest) {
  const { service, location } = await req.json();

  if (!service || !location) {
    return NextResponse.json({ error: "service and location are required" }, { status: 400 });
  }

  const expandedTerms = expandSearchTerm(service);

  const providerResults = await Promise.all(
    ALL_PROVIDERS.map((p) => runProviderSafely(p, { service, location, expandedTerms }))
  );

  const merged = dedupeBusinesses(providerResults.flat());

  const scored = merged.map((b) => {
    const { score, breakdown } = computeLeadScore(b);
    return {
      ...b,
      leadScore: score,
      leadScoreBreakdown: breakdown,
      summary: generateSummary(b),
    };
  });

  scored.sort((a, b) => (b.leadScore ?? 0) - (a.leadScore ?? 0));

  return NextResponse.json({
    query: { service, location, expandedTerms },
    count: scored.length,
    results: scored,
  });
}
