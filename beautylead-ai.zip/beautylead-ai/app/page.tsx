"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { Search, MapPin, ArrowRight } from "lucide-react";
import { Header } from "@/components/Header";
import { CategoryGrid } from "@/components/CategoryGrid";

const LOCATION_EXAMPLES = ["Baltimore", "DMV", "Prince George's County", "Washington DC", "Near me", "Atlanta"];

export default function Home() {
  const router = useRouter();
  const [step, setStep] = useState<"service" | "location">("service");
  const [service, setService] = useState("");
  const [location, setLocation] = useState("");

  function goToLocation() {
    if (service.trim().length === 0) return;
    setStep("location");
  }

  function submit(finalLocation?: string) {
    const loc = (finalLocation ?? location).trim();
    if (!loc) return;
    router.push(`/search?service=${encodeURIComponent(service)}&location=${encodeURIComponent(loc)}`);
  }

  return (
    <main className="min-h-screen">
      <Header />
      <div className="container-lead flex min-h-[calc(100vh-4rem)] flex-col items-center justify-center py-16">
        {step === "service" ? (
          <div key="service" className="w-full max-w-2xl animate-rise text-center">
            <p className="mb-3 text-sm font-medium uppercase tracking-[0.14em] text-berry">Step 1 of 2</p>
            <h1 className="font-display text-4xl leading-tight sm:text-5xl">
              What type of <span className="italic text-berry">beauty service</span> are you looking for?
            </h1>
            <div className="mt-8 flex items-center gap-2 rounded-full border border-line bg-white px-5 py-3.5 shadow-card focus-within:border-berry">
              <Search className="h-5 w-5 shrink-0 text-muted" />
              <input
                autoFocus
                value={service}
                onChange={(e) => setService(e.target.value)}
                onKeyDown={(e) => e.key === "Enter" && goToLocation()}
                placeholder="e.g. Silk press stylist, Russian volume lash tech..."
                className="w-full bg-transparent text-base outline-none placeholder:text-muted"
              />
              <button
                onClick={goToLocation}
                disabled={!service.trim()}
                className="flex shrink-0 items-center gap-1 rounded-full bg-berry px-4 py-2 text-sm font-medium text-white transition-opacity disabled:opacity-30"
              >
                Next <ArrowRight className="h-4 w-4" />
              </button>
            </div>
            <p className="mt-8 mb-3 text-sm text-muted">Or pick a category</p>
            <CategoryGrid selected={service} onSelect={(c) => { setService(c); }} />
          </div>
        ) : (
          <div key="location" className="w-full max-w-xl animate-rise text-center">
            <p className="mb-3 text-sm font-medium uppercase tracking-[0.14em] text-berry">Step 2 of 2</p>
            <h1 className="font-display text-4xl leading-tight sm:text-5xl">
              What <span className="italic text-berry">location</span>?
            </h1>
            <p className="mt-3 text-muted">Searching for <span className="font-medium text-ink">{service}</span></p>
            <div className="mt-8 flex items-center gap-2 rounded-full border border-line bg-white px-5 py-3.5 shadow-card focus-within:border-berry">
              <MapPin className="h-5 w-5 shrink-0 text-muted" />
              <input
                autoFocus
                value={location}
                onChange={(e) => setLocation(e.target.value)}
                onKeyDown={(e) => e.key === "Enter" && submit()}
                placeholder="City, neighborhood, or 'near me'"
                className="w-full bg-transparent text-base outline-none placeholder:text-muted"
              />
              <button
                onClick={() => submit()}
                disabled={!location.trim()}
                className="flex shrink-0 items-center gap-1 rounded-full bg-berry px-4 py-2 text-sm font-medium text-white transition-opacity disabled:opacity-30"
              >
                Search <ArrowRight className="h-4 w-4" />
              </button>
            </div>
            <div className="mt-6 flex flex-wrap justify-center gap-2">
              {LOCATION_EXAMPLES.map((ex) => (
                <button
                  key={ex}
                  onClick={() => { setLocation(ex); submit(ex); }}
                  className="rounded-full border border-line bg-white px-3.5 py-1.5 text-sm text-muted hover:border-berry-400 hover:text-berry-600"
                >
                  {ex}
                </button>
              ))}
            </div>
            <button onClick={() => setStep("service")} className="mt-8 text-sm text-muted hover:text-ink">
              ← Back
            </button>
          </div>
        )}
      </div>
    </main>
  );
}
