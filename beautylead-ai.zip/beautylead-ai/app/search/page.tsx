"use client";

import { Suspense, useEffect, useMemo, useState } from "react";
import { useSearchParams, useRouter } from "next/navigation";
import { useQuery } from "@tanstack/react-query";
import { Header } from "@/components/Header";
import { ProgressSearch } from "@/components/ProgressSearch";
import { BusinessCard } from "@/components/BusinessCard";
import { FilterPanel } from "@/components/FilterPanel";
import { MapView } from "@/components/MapView";
import { Business, SearchFilters } from "@/lib/types";
import { generateInsights } from "@/lib/aiSummary";
import { Sparkles, Download } from "lucide-react";

const MIN_PROGRESS_MS = 2600;
const FAVORITES_KEY = "beautylead:favorites";

function SearchPageInner() {
  const params = useSearchParams();
  const router = useRouter();
  const service = params.get("service") ?? "";
  const location = params.get("location") ?? "";

  const [filters, setFilters] = useState<SearchFilters>({});
  const [selectedId, setSelectedId] = useState<string | null>(null);
  const [favorites, setFavorites] = useState<Set<string>>(new Set());
  const [minTimeElapsed, setMinTimeElapsed] = useState(false);

  useEffect(() => {
    const t = setTimeout(() => setMinTimeElapsed(true), MIN_PROGRESS_MS);
    return () => clearTimeout(t);
  }, []);

  useEffect(() => {
    try {
      const raw = localStorage.getItem(FAVORITES_KEY);
      if (raw) setFavorites(new Set(JSON.parse(raw)));
    } catch {}
  }, []);

  function toggleFavorite(id: string) {
    setFavorites((prev) => {
      const next = new Set(prev);
      next.has(id) ? next.delete(id) : next.add(id);
      localStorage.setItem(FAVORITES_KEY, JSON.stringify(Array.from(next)));
      return next;
    });
  }

  const { data, isLoading, isError } = useQuery({
    queryKey: ["search", service, location],
    queryFn: async () => {
      const res = await fetch("/api/search", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ service, location }),
      });
      if (!res.ok) throw new Error("Search failed");
      return res.json() as Promise<{ results: Business[]; count: number }>;
    },
    enabled: Boolean(service && location),
  });

  const showProgress = isLoading || !minTimeElapsed;

  const filtered = useMemo(() => {
    if (!data?.results) return [];
    return data.results.filter((b) => {
      if (filters.minRating && (b.rating ?? 0) < filters.minRating) return false;
      if (filters.distance && (b.distanceMiles ?? 999) > filters.distance) return false;
      if (filters.priceTier && b.attributes?.priceTier !== filters.priceTier) return false;
      const boolChecks: (keyof SearchFilters)[] = [
        "openNow", "blackOwned", "womenOwned", "spanishSpeaking", "kidFriendly",
        "wheelchairAccessible", "onlineBooking", "walkIns", "mobileService",
        "organicProducts", "veganProducts", "openWeekends", "openLate",
      ];
      for (const key of boolChecks) {
        if (filters[key] && !(key === "openNow" ? b.openNow : (b.attributes as any)?.[key])) return false;
      }
      return true;
    });
  }, [data, filters]);

  const insights = useMemo(() => (data ? generateInsights(filtered, service) : []), [data, filtered, service]);

  function exportFavoritesCsv() {
    const favs = (data?.results ?? []).filter((b) => favorites.has(b.id));
    const header = ["Name", "Category", "Address", "Phone", "Website", "Email", "Rating", "Lead Score"];
    const rows = favs.map((b) => [b.name, b.category, b.address, b.phone ?? "", b.website ?? "", b.email ?? "", b.rating ?? "", b.leadScore ?? ""]);
    const csv = [header, ...rows].map((r) => r.map((v) => `"${String(v).replace(/"/g, '""')}"`).join(",")).join("\n");
    const blob = new Blob([csv], { type: "text/csv" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = "beautylead-favorites.csv";
    a.click();
    URL.revokeObjectURL(url);
  }

  if (!service || !location) {
    return (
      <main className="min-h-screen">
        <Header />
        <div className="container-lead py-20 text-center text-muted">
          Missing search details. <button onClick={() => router.push("/")} className="text-berry underline">Start a new search</button>
        </div>
      </main>
    );
  }

  return (
    <main className="min-h-screen">
      <Header />
      {showProgress ? (
        <div className="container-lead py-10">
          <ProgressSearch service={service} location={location} />
        </div>
      ) : isError ? (
        <div className="container-lead py-20 text-center text-muted">
          Something went wrong. <button onClick={() => router.refresh()} className="text-berry underline">Try again</button>
        </div>
      ) : (
        <div className="container-lead py-8">
          <div className="mb-6 flex flex-wrap items-end justify-between gap-3">
            <div>
              <h1 className="font-display text-3xl">
                {service} <span className="text-muted">in</span> {location}
              </h1>
              <p className="mt-1 text-sm text-muted">{filtered.length} of {data?.count ?? 0} results</p>
            </div>
            {favorites.size > 0 && (
              <button onClick={exportFavoritesCsv} className="flex items-center gap-1.5 rounded-full border border-line bg-white px-4 py-2 text-sm hover:border-berry-400">
                <Download className="h-4 w-4" /> Export {favorites.size} favorite{favorites.size > 1 ? "s" : ""}
              </button>
            )}
          </div>

          {insights.length > 0 && (
            <div className="mb-6 flex gap-3 overflow-x-auto pb-1">
              {insights.map((ins) => {
                const b = data?.results.find((r) => r.id === ins.businessId);
                if (!b) return null;
                return (
                  <button
                    key={ins.label}
                    onClick={() => setSelectedId(b.id)}
                    className="flex shrink-0 items-center gap-2 rounded-full border border-gold-100 bg-gold-100/40 px-4 py-2 text-sm hover:border-gold-400"
                  >
                    <Sparkles className="h-3.5 w-3.5 text-gold-500" />
                    <span className="text-muted">{ins.label}:</span>
                    <span className="font-medium">{b.name}</span>
                  </button>
                );
              })}
            </div>
          )}

          <div className="grid grid-cols-1 gap-6 lg:grid-cols-[240px_1fr_320px]">
            <div className="order-2 lg:order-1">
              <FilterPanel filters={filters} onChange={setFilters} resultCount={filtered.length} />
            </div>

            <div className="order-1 grid grid-cols-1 gap-4 sm:grid-cols-2 lg:order-2">
              {filtered.map((b) => (
                <BusinessCard
                  key={b.id}
                  business={b}
                  selected={selectedId === b.id}
                  onSelect={() => setSelectedId(b.id)}
                  isFavorite={favorites.has(b.id)}
                  onToggleFavorite={() => toggleFavorite(b.id)}
                />
              ))}
              {filtered.length === 0 && (
                <p className="col-span-full py-16 text-center text-muted">No results match your filters. Try loosening them.</p>
              )}
            </div>

            <div className="order-3 hidden lg:block">
              <MapView businesses={filtered} selectedId={selectedId} onSelect={setSelectedId} />
            </div>
          </div>
        </div>
      )}
    </main>
  );
}

export default function SearchPage() {
  return (
    <Suspense fallback={null}>
      <SearchPageInner />
    </Suspense>
  );
}
